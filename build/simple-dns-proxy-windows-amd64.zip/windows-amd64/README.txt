Simple DNS Proxy

USAGE:
  1. Edit config.yaml to match your DNS settings
  2. Run the application with administrator/root privileges
     (required for binding to port 53, which is privileged)

Configuration:
  See config.yaml for all available options

For more information, visit the project repository.
